import React, { useState } from "react";
import { useHistory } from "react-router";

export default function Summary(){


  const[total , setTotal]=useState([])

    const history=useHistory();
      var val=[]
    fetch("http://localhost:8083/premium/get",{
        method:"GET",
        headers:{"Content-Type":"application/json"},
      }).then((result)=>result.json())
      .then((data)=>{
        setTotal(data);
          console.log(data)
      })
      console.log(val)
    
    const handleClick3=()=>{
        history.push("/Home")
    }

    return(
        <>
        {/* {state.map((item) => (
        <tr key={item.id}>
          {Object.values(item).map((val) => (
            <td>{val}</td>
          ))}
        </tr>
      ))} */}

        <button type="button" class="btn btn-danger" style={{ textAlign:"center", width:"100px" , height:"50px" , marginLeft:"1200px" , marginTop:"50px"}} onClick={handleClick3}>LOGOUT</button>
        <div className="container" style={{backgroundColor:"silver" ,width:"1600px", height:"650px" ,textAlign:"center" , paddingTop:"30px" , paddingBottom:"20px" , marginTop:"50px"}}>
        <h1 style={{textAlign:"center"}}>Premium Summary</h1>
        
        <br/>
        <br/>

        <table class="table">

          total.map((item)=>{
            return {<tr><td>{item.id}</td></tr>}
          })
          </table>
        <table class="table">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Name</th>
      <th scope="col">Nature of Insurance</th>
      <th scope="col">Type Of Insurance</th>
      <th scope="col">Total Vehicle</th>
      <th scope="col">Premium Purchase Date</th>
      <th scope="col">Premium Amount</th>
      
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td></td>
      <td>Individual</td>
      <td>Automobile</td>
      <td>1</td>
      <td>10/03/2021</td>
      <td>3000</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Pulkit</td>
      <td>Business</td>
      <td>Automobile</td>
      <td>10</td>
      <td>10/03/2019</td>
      <td>10000</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Naman</td>
      <td>Individual</td>
      <td>Automobile</td>
      <td>1</td>
      <td>10/05/2021</td>
      <td>5000</td>
    </tr>
    <tr>
      <th scope="row">4</th>
      <td>Mainaz</td>
      <td>Individual</td>
      <td>Automobile</td>
      <td>1</td>
      <td>20/03/2021</td>
      <td>2000</td>
    </tr>
    <tr>
      <th scope="row">5</th>
      <td>Ashish</td>
      <td>Business</td>
      <td>Automobile</td>
      <td>5</td>
      <td>10/08/2021</td>
      <td>8000</td>
    </tr>
    <tr>
      <th scope="row">6</th>
      <td>Vaibhav</td>
      <td>Individual</td>
      <td>Automobile</td>
      <td>1</td>
      <td>10/12/2021</td>
      <td>3500</td>
    </tr>
    <tr>
      <th scope="row">7</th>
      <td>Sarthak</td>
      <td>Business</td>
      <td>Automobile</td>
      <td>4</td>
      <td>10/03/2020</td>
      <td>6000</td>
    </tr>
    
    
  </tbody>
</table>
        
        </div>
        </>
    )
}