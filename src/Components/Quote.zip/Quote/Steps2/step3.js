import React,{useState} from "react";
import { Box, Grid, Paper } from "@material-ui/core";
import { styles } from "../common/styles";
import {
  renderButton,
  renderInputField,
  renderSelect,
  renderText,
} from "../common/DisplayComponent";
  import "./step3.css";

 const Step3=({
  state,
    handleChange,
    handleNext,
    handlePrev,
    handleSubmit,
 })=>{

  const [inputfields , setinputfields]=useState([
    {vehicletype:'',registration:'',fueltype:'',amountpurchase:'',enginecapacity:'',purchasedate:''},
  ])

  const handleAddFields=()=>{
    setinputfields([...inputfields,{vehicletype:'',registration:'',fueltype:'',amountpurchase:'',enginecapacity:'',purchasedate:''}])
  }
  return (
    <Paper style={styles.steps}>
    
     
      <Box mt={2} mb={2}>
        {renderText({
          label: "VEHICLE DETAILS",
          type: "h6",
          color: "textPrimary",
          align: "center",
        })}
      </Box>
      <br/>

     {inputfields.map((inputfield,index)=>(
       <div key={index}>
         <br/>

         <Grid container spacing={1} style={{ marginBottom: "16px" }}>
        <Grid item xs={12} sm={6}>
          <div className="select_field">
        <select >
                    <option disabled hidden selected>Vehicle Type</option>
                    <option value="Two Wheeler">Two Wheeler</option>
                    <option value="Three Wheeler">Three Wheeler</option>
                    <option value="Four Wheeler">Four Wheeler</option>
                    <option value="Eight Wheeler">Eight Wheeler</option>
                </select>
                </div>
        </Grid>
        <Grid item xs={12} sm={6}>
          <div className="txt_field">
          
         <label>Registration Number<input type="text" required/></label>
         
         </div>
        </Grid>
        </Grid>
        
     
     

     <Grid container spacing={1} style={{ marginBottom: "16px" }}>
       

        <Grid item xs={12} sm={6}>
        <div className="select_field">
        <select >
                    <option disabled hidden selected>Fuel Type</option>
                    <option value="Diesel">DIESEL</option>
                    <option value="Petrol">PETROL</option>
                    <option value="CNG">CNG</option>
                </select>
                </div>
         
        </Grid>

        <Grid item xs={12} sm={6}>
          <div className="txt_field">
        <label>Engine Capacity<input type="text"/></label>
         </div>
         
        </Grid>
      </Grid> 

      <Grid container spacing={1} style={{ marginBottom: "16px" }}>
        <Grid item xs={12} sm={6}>
        <div className="txt_field">
         <label>Vehicle Purchase Amount<input type="number"/></label>
        
         </div>
        </Grid>

        <Grid item xs={12} sm={6}>
        <div className="txt_field">
        <label>Vehicle Purchase Date<input type="date"/></label>
         
         </div>
        </Grid>
        
      </Grid> 
     <br/>
     <br/>
      <br/>
      <hr/>
      <br/>
      </div>
       
     ))}
     <Grid container component={Box} justify='flex-end' mt={2} p={2}>
       <Box ml={2}>
         {renderButton({ label: "+",onClick:handleAddFields})}
       </Box>
     </Grid>

     <Grid container component={Box} justify='flex-end' mt={2} p={2}>
        <Box ml={2}>
          {renderButton({
            label: "Back",
            color: "default",
            onClick: handlePrev,
          })}
        </Box>
        <Box ml={2}>
          {renderButton({ label: "Finish", onClick: handleNext })}
        </Box>
      </Grid>
   </Paper> 
    // {/* </Paper> */}
  );


};

export default Step3;