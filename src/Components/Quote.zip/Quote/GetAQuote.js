import React, { Component, useState } from "react";
import './getaquote.css'
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom'
import GetAQuote1 from './GetAQuote1';
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";

function GetAQuote (){
    const [first,last]=useState("")
    let history=useHistory()
    function clickHandlers(){
        if(first==="individual"){
          history.push("/getaquote1")

        }
        else{
            history.push("/getaquote2")
        }
           
             

    }

   
    
   return (
        <>
        <div className="container">
            <form className="form">
                <h1>Nature Of Insurance</h1>
                <hr/>
                <select onChange={(e)=>{last(e.target.value)}}>
                    <option disabled hidden selected>Select</option>
                    <option value="individual">Individual</option>
                    <option value="business">Business</option>
                </select>
                <br/>
                <button onClick={clickHandlers}>Submit</button>
             
            </form>
        </div>
       
        </>

    )

}

export default GetAQuote;